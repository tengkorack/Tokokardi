<?php
		$conn =new mysqli('localhost', 'root', '' , 'tokokardi');
?>